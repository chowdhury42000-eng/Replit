import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import AnnouncementBar from "@/components/AnnouncementBar";
import TopQuickBar from "@/components/TopQuickBar";
import MegaMenuNav from "@/components/MegaMenuNav";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Download, Loader2, Wand2, ShoppingCart, Edit } from "lucide-react";

interface DesignResult {
  imageUrl: string;
  prompt: string;
}

export default function AICapDesigner() {
  const [prompt, setPrompt] = useState("");
  const [capStyle, setCapStyle] = useState("baseball");
  const [designResult, setDesignResult] = useState<DesignResult | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlPrompt = params.get("prompt");
    const urlCapStyle = params.get("capStyle");

    if (urlPrompt) {
      setPrompt(urlPrompt);
    }
    if (urlCapStyle) {
      setCapStyle(urlCapStyle);
    }

    if (urlPrompt || urlCapStyle) {
      toast({
        title: "Design Loaded for Editing",
        description: "Your previous design has been loaded. Modify it and generate a new version!",
      });
    }
  }, []);

  const generateDesign = useMutation({
    mutationFn: async (data: { prompt: string; capStyle: string }) => {
      const response = await fetch("/api/ai/generate-cap-design", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to generate design");
      }

      return response.json();
    },
    onSuccess: async (data) => {
      setDesignResult(data);
      
      let saved = false;
      try {
        const saveResponse = await fetch("/api/designs", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            imageUrl: data.imageUrl,
            prompt: data.prompt,
            capStyle: capStyle,
          }),
        });

        if (saveResponse.ok) {
          saved = true;
        } else {
          console.error("Failed to save design to database");
        }
      } catch (error) {
        console.error("Error saving design:", error);
      }

      toast({
        title: "Design Generated! 🎨",
        description: saved 
          ? "Your custom cap design is ready and saved!" 
          : "Design generated but couldn't be saved. You can still download it.",
        variant: saved ? "default" : "destructive",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt Required",
        description: "Please describe your cap design idea",
        variant: "destructive",
      });
      return;
    }

    generateDesign.mutate({ prompt, capStyle });
  };

  const handleDownload = async () => {
    if (!designResult?.imageUrl) return;

    try {
      const response = await fetch(designResult.imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `custom-cap-design-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Downloaded! 📥",
        description: "Your design has been saved",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Could not download the image",
        variant: "destructive",
      });
    }
  };

  const examplePrompts = [
    "A vibrant streetwear cap with graffiti art and neon colors",
    "Minimalist black cap with geometric golden patterns",
    "Vintage baseball cap with retro 80s aesthetic and pastel colors",
    "Futuristic cap with holographic elements and cyber patterns",
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <AnnouncementBar />
      <TopQuickBar />
      <MegaMenuNav />

      <main className="flex-1 container mx-auto px-4 py-12 max-w-7xl">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-yellow-500" />
            <h1 className="text-4xl md:text-5xl font-bold">AI Cap Designer</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Create unique custom cap designs using AI. Describe your vision and watch it come to life!
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wand2 className="w-5 h-5" />
                Design Your Cap
              </CardTitle>
              <CardDescription>
                Describe your dream cap design in detail
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="cap-style">Cap Style</Label>
                <Select value={capStyle} onValueChange={setCapStyle}>
                  <SelectTrigger id="cap-style">
                    <SelectValue placeholder="Select cap style" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="baseball">Baseball Cap</SelectItem>
                    <SelectItem value="trucker">Trucker Cap</SelectItem>
                    <SelectItem value="snapback">Snapback</SelectItem>
                    <SelectItem value="bucket">Bucket Hat</SelectItem>
                    <SelectItem value="dad-hat">Dad Hat</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="design-prompt">Design Description</Label>
                <Textarea
                  id="design-prompt"
                  placeholder="Describe your cap design... (e.g., 'A modern streetwear cap with bold abstract patterns in blue and gold')"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={6}
                  className="resize-none"
                />
                <p className="text-sm text-muted-foreground">
                  Be specific about colors, patterns, themes, and style
                </p>
              </div>

              <div className="space-y-2">
                <Label>Example Prompts</Label>
                <div className="space-y-2">
                  {examplePrompts.map((example, idx) => (
                    <button
                      key={idx}
                      onClick={() => setPrompt(example)}
                      className="w-full text-left text-sm p-3 rounded-lg border hover:bg-accent transition-colors"
                    >
                      {example}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={generateDesign.isPending}
                className="w-full"
                size="lg"
              >
                {generateDesign.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating Design...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    Generate Design
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Your Design</CardTitle>
              <CardDescription>
                AI-generated cap design preview
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-square bg-muted rounded-lg flex items-center justify-center overflow-hidden">
                {designResult ? (
                  <img
                    src={designResult.imageUrl}
                    alt="Generated cap design"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center p-8">
                    <Wand2 className="w-16 h-16 mx-auto mb-4 text-muted-foreground/50" />
                    <p className="text-muted-foreground">
                      Your generated design will appear here
                    </p>
                  </div>
                )}
              </div>

              {designResult && (
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-1">Design Prompt:</p>
                    <p className="text-sm text-muted-foreground">
                      {designResult.prompt}
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        toast({
                          title: "Coming Soon! 🛒",
                          description: "Custom cap ordering will be available soon. Your design has been saved!",
                        });
                      }}
                      className="flex-1"
                      size="lg"
                    >
                      <ShoppingCart className="mr-2 h-5 w-5" />
                      Order The Cap
                    </Button>
                    <Button
                      onClick={() => {
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                        toast({
                          title: "Edit Your Design",
                          description: "Modify the prompt above and generate a new version!",
                        });
                      }}
                      className="flex-1"
                      size="lg"
                      variant="outline"
                    >
                      <Edit className="mr-2 h-5 w-5" />
                      Edit This Cap
                    </Button>
                  </div>
                  
                  <Button
                    onClick={handleDownload}
                    className="w-full"
                    variant="secondary"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download Design
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="mt-12 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-2xl p-8">
          <h2 className="text-2xl font-bold mb-4">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="w-12 h-12 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold text-lg">
                1
              </div>
              <h3 className="font-semibold">Choose Your Style</h3>
              <p className="text-sm text-muted-foreground">
                Select from baseball, trucker, bucket hat, and more
              </p>
            </div>
            <div className="space-y-2">
              <div className="w-12 h-12 rounded-full bg-purple-500 text-white flex items-center justify-center font-bold text-lg">
                2
              </div>
              <h3 className="font-semibold">Describe Your Vision</h3>
              <p className="text-sm text-muted-foreground">
                Use AI to transform your ideas into unique designs
              </p>
            </div>
            <div className="space-y-2">
              <div className="w-12 h-12 rounded-full bg-pink-500 text-white flex items-center justify-center font-bold text-lg">
                3
              </div>
              <h3 className="font-semibold">Download & Order</h3>
              <p className="text-sm text-muted-foreground">
                Save your design and bring it to life
              </p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
