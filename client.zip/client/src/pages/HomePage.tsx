import AnnouncementBar from "@/components/AnnouncementBar";
import TopQuickBar from "@/components/TopQuickBar";
import MegaMenuNav from "@/components/MegaMenuNav";
import HeroSlider from "@/components/HeroSlider";
import PromoBanners from "@/components/PromoBanners";
import HorizontalProductScroll from "@/components/HorizontalProductScroll";
import LargeCollectionCards from "@/components/LargeCollectionCards";
import Footer from "@/components/Footer";

// Mock data for product sections
import product1 from "@assets/stock_images/baseball_cap_collect_2f97991c.jpg";
import product2 from "@assets/stock_images/baseball_cap_collect_69e4133c.jpg";
import product3 from "@assets/stock_images/baseball_cap_collect_32e1612e.jpg";
import product4 from "@assets/stock_images/baseball_cap_collect_fb891299.jpg";
import product5 from "@assets/stock_images/baseball_cap_collect_3b30f7ef.jpg";
import trucker1 from "@assets/stock_images/stylish_trucker_cap__b5550fe7.jpg";
import trucker2 from "@assets/stock_images/stylish_trucker_cap__dd9d694f.jpg";
import trucker3 from "@assets/stock_images/stylish_trucker_cap__714fb0e5.jpg";
import trucker4 from "@assets/stock_images/stylish_trucker_cap__974d6efb.jpg";
import bucket1 from "@assets/stock_images/bucket_hat_fashion_l_b9d2c6fa.jpg";
import bucket2 from "@assets/stock_images/bucket_hat_fashion_l_94ff8818.jpg";
import flat1 from "@assets/stock_images/flat_visor_cap_snapb_0f80e268.jpg";
import flat2 from "@assets/stock_images/flat_visor_cap_snapb_7d7adfb3.jpg";

const newCapSeries = [
  { id: "truly-classic", image: product1, title: "TRULY CLASSIC" },
  { id: "acti-flex", image: trucker1, title: "ACTI FLEX" },
  { id: "high-crown", image: product2, title: "HIGH CROWN CAPS" },
  { id: "denim-fuse", image: product3, title: "DENIM FUSE CAP SERIES" },
  { id: "edge-series", image: trucker2, title: "EDGE SERIES" },
  { id: "mismatch", image: product4, title: "MISMATCH CAPS" },
  { id: "kids-cap", image: product5, title: "KIDS CAP" },
];

const whatsHappeningNew = [
  { id: "limited-1", image: trucker3, title: "LIMITED EDITION CAP" },
  { id: "flash-1", image: trucker4, title: "FLASH SALE SPECIAL" },
  { id: "trending-1", image: bucket1, title: "TRENDING BUCKET HAT" },
  { id: "new-1", image: bucket2, title: "NEW ARRIVAL" },
  { id: "exclusive-1", image: flat1, title: "EXCLUSIVE FLAT VISOR" },
  { id: "premium-1", image: flat2, title: "PREMIUM SNAPBACK" },
];

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <AnnouncementBar />
      <TopQuickBar />
      <MegaMenuNav />
      
      <main className="flex-1">
        <HeroSlider />
        <PromoBanners />
        
        <HorizontalProductScroll
          title="NEW CAP SERIES"
          products={newCapSeries}
        />
        
        <HorizontalProductScroll
          title="What's Happening New"
          products={whatsHappeningNew}
        />
        
        <LargeCollectionCards />
      </main>
      
      <Footer />
    </div>
  );
}
