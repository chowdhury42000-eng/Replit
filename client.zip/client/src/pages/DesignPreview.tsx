import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AnnouncementBar from "@/components/AnnouncementBar";
import TopQuickBar from "@/components/TopQuickBar";
import MegaMenuNav from "@/components/MegaMenuNav";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Eye, Download, Trash2, Sparkles, Image as ImageIcon, Edit, ShoppingCart } from "lucide-react";
import { Link, useLocation } from "wouter";

interface Design {
  id: number;
  imageUrl: string;
  prompt: string;
  capStyle: string;
  createdAt: string;
}

export default function DesignPreview() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedDesign, setSelectedDesign] = useState<Design | null>(null);
  const [, setLocation] = useLocation();

  const { data: designs = [], isLoading } = useQuery<Design[]>({
    queryKey: ["designs"],
    queryFn: async () => {
      const response = await fetch("/api/designs");
      if (!response.ok) throw new Error("Failed to fetch designs");
      return response.json();
    },
  });

  const deleteDesign = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/designs/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("Failed to delete design");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["designs"] });
      toast({
        title: "Design Deleted",
        description: "Your design has been removed",
      });
      setSelectedDesign(null);
    },
    onError: () => {
      toast({
        title: "Delete Failed",
        description: "Could not delete the design",
        variant: "destructive",
      });
    },
  });

  const handleDownload = async (design: Design) => {
    try {
      const response = await fetch(design.imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `cap-design-${design.id}.png`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Downloaded! 📥",
        description: "Your design has been saved",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Could not download the image",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <AnnouncementBar />
      <TopQuickBar />
      <MegaMenuNav />

      <main className="flex-1 container mx-auto px-4 py-12 max-w-7xl">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 mb-4">
            <Eye className="w-8 h-8 text-blue-500" />
            <h1 className="text-4xl md:text-5xl font-bold">Design Preview</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            View, manage, and download your AI-generated cap designs
          </p>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Loading your designs...</p>
          </div>
        ) : designs.length === 0 ? (
          <Card className="max-w-2xl mx-auto">
            <CardContent className="pt-12 pb-12 text-center">
              <ImageIcon className="w-16 h-16 mx-auto mb-4 text-muted-foreground/50" />
              <h3 className="text-xl font-semibold mb-2">No Designs Yet</h3>
              <p className="text-muted-foreground mb-6">
                You haven't created any cap designs yet. Start designing to see them here!
              </p>
              <Link href="/design-your-cap">
                <Button size="lg">
                  <Sparkles className="mr-2 h-4 w-4" />
                  Create Your First Design
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-bold mb-6">Your Designs ({designs.length})</h2>
              <div className="space-y-4">
                {designs.map((design) => (
                  <Card
                    key={design.id}
                    className={`cursor-pointer transition-all ${
                      selectedDesign?.id === design.id
                        ? "ring-2 ring-primary"
                        : "hover:shadow-lg"
                    }`}
                    onClick={() => setSelectedDesign(design)}
                  >
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <div className="w-24 h-24 rounded-lg overflow-hidden flex-shrink-0 bg-muted">
                          <img
                            src={design.imageUrl}
                            alt={design.prompt}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-sm mb-1 capitalize">
                                {design.capStyle.replace("-", " ")} Cap
                              </p>
                              <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                                {design.prompt}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {formatDate(design.createdAt)}
                              </p>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteDesign.mutate(design.id);
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="sticky top-24 h-fit">
              <Card>
                <CardHeader>
                  <CardTitle>Design Details</CardTitle>
                  <CardDescription>
                    {selectedDesign
                      ? "Preview and download your design"
                      : "Select a design to preview"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {selectedDesign ? (
                    <div className="space-y-6">
                      <div className="aspect-square bg-muted rounded-lg overflow-hidden">
                        <img
                          src={selectedDesign.imageUrl}
                          alt={selectedDesign.prompt}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      <div className="space-y-4">
                        <div>
                          <p className="text-sm font-medium mb-1">Cap Style</p>
                          <p className="text-sm text-muted-foreground capitalize">
                            {selectedDesign.capStyle.replace("-", " ")}
                          </p>
                        </div>

                        <div>
                          <p className="text-sm font-medium mb-1">Design Prompt</p>
                          <p className="text-sm text-muted-foreground">
                            {selectedDesign.prompt}
                          </p>
                        </div>

                        <div>
                          <p className="text-sm font-medium mb-1">Created</p>
                          <p className="text-sm text-muted-foreground">
                            {formatDate(selectedDesign.createdAt)}
                          </p>
                        </div>

                        <div className="space-y-3 pt-2">
                          <div className="flex gap-2">
                            <Button
                              onClick={() => {
                                const params = new URLSearchParams({
                                  prompt: selectedDesign.prompt,
                                  capStyle: selectedDesign.capStyle,
                                });
                                setLocation(`/design-your-cap?${params.toString()}`);
                              }}
                              className="flex-1"
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              Edit Cap
                            </Button>
                            <Button
                              onClick={() => {
                                toast({
                                  title: "Coming Soon! 🛒",
                                  description: "Custom cap ordering will be available soon. We'll save your design for when it's ready!",
                                });
                              }}
                              className="flex-1"
                              variant="default"
                            >
                              <ShoppingCart className="mr-2 h-4 w-4" />
                              Order This Cap
                            </Button>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              onClick={() => handleDownload(selectedDesign)}
                              variant="outline"
                              className="flex-1"
                            >
                              <Download className="mr-2 h-4 w-4" />
                              Download
                            </Button>
                            <Button
                              variant="outline"
                              onClick={() => deleteDesign.mutate(selectedDesign.id)}
                              className="flex-1"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Eye className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
                      <p className="text-muted-foreground">
                        Click on a design to view details
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
