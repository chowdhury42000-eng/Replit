import banner1 from "@assets/stock_images/baseball_cap_collect_2f97991c.jpg";
import banner2 from "@assets/stock_images/baseball_cap_collect_69e4133c.jpg";

export default function PromoBanners() {
  return (
    <section className="py-6" data-testid="section-promo-banners">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="relative group overflow-hidden rounded-lg cursor-pointer hover-elevate" data-testid="banner-limited-edition">
            <div className="aspect-[16/9] overflow-hidden">
              <img
                src={banner1}
                alt="Limited Edition"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent flex flex-col justify-end p-6">
              <h3 className="text-white text-2xl font-bold mb-2">LIMITED EDITION</h3>
              <p className="text-white/90 text-sm mb-3">Exclusive Designs - Limited Stock</p>
              <button className="bg-white text-foreground px-6 py-2 rounded-md font-semibold hover-elevate w-fit">
                Shop Now
              </button>
            </div>
          </div>

          <div className="relative group overflow-hidden rounded-lg cursor-pointer hover-elevate" data-testid="banner-anniversary">
            <div className="aspect-[16/9] overflow-hidden">
              <img
                src={banner2}
                alt="Anniversary Edition"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent flex flex-col justify-end p-6">
              <h3 className="text-white text-2xl font-bold mb-2">ANNIVERSARY EDITION</h3>
              <p className="text-white/90 text-sm mb-3">Celebrate with Special Collection</p>
              <button className="bg-white text-foreground px-6 py-2 rounded-md font-semibold hover-elevate w-fit">
                Explore
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
