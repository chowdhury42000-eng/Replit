import { useState, useEffect } from "react";
import ProductCard from "./ProductCard";
import { Zap } from "lucide-react";
import product1 from "@assets/stock_images/baseball_cap_collect_2f97991c.jpg";
import product2 from "@assets/stock_images/baseball_cap_collect_69e4133c.jpg";
import product3 from "@assets/stock_images/baseball_cap_collect_32e1612e.jpg";
import product4 from "@assets/stock_images/baseball_cap_collect_fb891299.jpg";

const flashProducts = [
  { id: "flash-1", image: product1, title: "Urban Style Baseball Cap", price: 24.99, originalPrice: 49.99 },
  { id: "flash-2", image: product2, title: "Premium Suede Cap", price: 34.99, originalPrice: 69.99 },
  { id: "flash-3", image: product3, title: "Classic Trucker Hat", price: 19.99, originalPrice: 39.99 },
  { id: "flash-4", image: product4, title: "Vintage Baseball Cap", price: 29.99, originalPrice: 59.99 },
];

export default function FlashSaleSection() {
  const [timeLeft, setTimeLeft] = useState({
    hours: 12,
    minutes: 34,
    seconds: 56,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-12 md:py-16 bg-gradient-to-br from-chart-3/10 to-chart-3/5" data-testid="section-flash-sale">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-chart-3 rounded-lg">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-3xl font-bold" data-testid="text-flash-sale-title">Flash Sale</h2>
              <p className="text-muted-foreground" data-testid="text-flash-sale-subtitle">Limited time offers - Don't miss out!</p>
            </div>
          </div>

          <div className="flex gap-3" data-testid="countdown-timer">
            <div className="text-center bg-background rounded-lg p-3 min-w-[60px]">
              <div className="text-2xl font-bold" data-testid="text-hours">{String(timeLeft.hours).padStart(2, '0')}</div>
              <div className="text-xs text-muted-foreground">Hours</div>
            </div>
            <div className="text-center bg-background rounded-lg p-3 min-w-[60px]">
              <div className="text-2xl font-bold" data-testid="text-minutes">{String(timeLeft.minutes).padStart(2, '0')}</div>
              <div className="text-xs text-muted-foreground">Mins</div>
            </div>
            <div className="text-center bg-background rounded-lg p-3 min-w-[60px]">
              <div className="text-2xl font-bold" data-testid="text-seconds">{String(timeLeft.seconds).padStart(2, '0')}</div>
              <div className="text-xs text-muted-foreground">Secs</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {flashProducts.map((product) => (
            <ProductCard key={product.id} {...product} badge="FLASH SALE" />
          ))}
        </div>
      </div>
    </section>
  );
}
