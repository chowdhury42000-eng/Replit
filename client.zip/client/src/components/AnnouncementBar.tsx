import { X } from "lucide-react";
import { useState } from "react";

export default function AnnouncementBar() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="bg-primary text-primary-foreground py-2 px-4 text-center relative" data-testid="announcement-bar">
      <p className="text-sm font-medium">
        BUILDING A CULTURE, ONE CAP AT A TIME! 🔥 500+ UNIQUE DESIGNS AVAILABLE NOW 🧢 FREE SHIPPING ON ORDERS OVER $50!
      </p>
      <button
        onClick={() => setIsVisible(false)}
        className="absolute right-4 top-1/2 -translate-y-1/2 hover-elevate active-elevate-2 p-1 rounded"
        data-testid="button-close-announcement"
        aria-label="Close announcement"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
