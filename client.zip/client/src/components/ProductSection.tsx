import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import ProductCard from "./ProductCard";

interface Product {
  id: string;
  image: string;
  title: string;
  price: number;
  originalPrice?: number;
  badge?: string;
}

interface ProductSectionProps {
  title: string;
  subtitle?: string;
  products: Product[];
  viewAllLink?: string;
}

export default function ProductSection({ title, subtitle, products, viewAllLink }: ProductSectionProps) {
  const sectionId = title.toLowerCase().replace(/\s+/g, '-');
  
  return (
    <section className="py-12 md:py-16" data-testid={`section-${sectionId}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold mb-2" data-testid={`text-${sectionId}-title`}>{title}</h2>
            {subtitle && <p className="text-muted-foreground" data-testid={`text-${sectionId}-subtitle`}>{subtitle}</p>}
          </div>
          {viewAllLink && (
            <Button variant="ghost" className="gap-2" data-testid={`button-view-all-${sectionId}`}>
              View All
              <ArrowRight className="w-4 h-4" />
            </Button>
          )}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} {...product} />
          ))}
        </div>
      </div>
    </section>
  );
}
