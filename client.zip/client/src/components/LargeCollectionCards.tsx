import baseball from "@assets/stock_images/baseball_cap_collect_fb891299.jpg";
import trucker from "@assets/stock_images/stylish_trucker_cap__714fb0e5.jpg";

export default function LargeCollectionCards() {
  return (
    <section className="py-12" data-testid="section-large-collections">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="relative group overflow-hidden rounded-lg cursor-pointer hover-elevate" data-testid="card-premium-suede">
            <div className="aspect-[4/3] overflow-hidden">
              <img
                src={baseball}
                alt="Premium Suede Collection"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex items-end p-8">
              <div>
                <h3 className="text-white text-3xl font-bold mb-2">PREMIUM SUEDE</h3>
                <p className="text-white/90 mb-4">Luxury fabric, timeless style</p>
                <button className="bg-white text-foreground px-8 py-3 rounded-md font-semibold hover-elevate">
                  Shop Collection
                </button>
              </div>
            </div>
          </div>

          <div className="relative group overflow-hidden rounded-lg cursor-pointer hover-elevate" data-testid="card-premium-curved">
            <div className="aspect-[4/3] overflow-hidden">
              <img
                src={trucker}
                alt="Premium Curved Visor Collection"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex items-end p-8">
              <div>
                <h3 className="text-white text-3xl font-bold mb-2">PREMIUM CURVED VISOR</h3>
                <p className="text-white/90 mb-4">Classic design, modern comfort</p>
                <button className="bg-white text-foreground px-8 py-3 rounded-md font-semibold hover-elevate">
                  Shop Collection
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
