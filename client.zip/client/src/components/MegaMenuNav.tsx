import { Search, ShoppingCart, Menu, X, ChevronDown } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const capCategories = [
  {
    title: "BASEBALL CAP",
    subcategories: ["BASIC SUEDE", "BASIC CORDUROY", "BASIC TWILL", "SANDWICH CAP", "WASHED CURVED VISOR", "PREMIUM CURVED VISOR", "EVERYDAY CURVED VISOR", "FITTED CAP"]
  },
  {
    title: "TRUCKER CAP",
    subcategories: ["High Crown Trucker", "Baseball Trucker", "Basic Trucker", "SUPER TRUCKER"]
  },
  {
    title: "FLAT VISOR",
    subcategories: ["Classic Flat Visor"]
  },
  {
    title: "BUCKET HAT",
    subcategories: ["Monotone Bucket", "Camo Bucket"]
  },
  {
    title: "KIDS CAP",
    subcategories: ["KIDS BASEBALL CAP", "LINEAGE CAP"]
  }
];

export default function MegaMenuNav() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const navItems = [
    { label: "Homepage", path: "/" },
    { label: "Design You Feel on Cap", path: "/design-your-cap" },
    { label: "Design Preview", path: "/preview" },
    { label: "Order Status", path: "/order-status" },
    { label: "About", path: "/about" },
    { label: "Contact", path: "/contact" },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <Link href="/" data-testid="link-home">
              <span className="text-2xl font-bold text-primary cursor-pointer">Friute Cap</span>
            </Link>
            
            <div className="hidden lg:flex items-center gap-1">
              {navItems.slice(0, 3).map((item) => (
                <Link key={item.path} href={item.path}>
                  <span className="text-sm font-medium px-3 py-2 rounded-md hover-elevate cursor-pointer" data-testid={`link-${item.label.toLowerCase().replace(/\s+/g, '-')}`}>
                    {item.label}
                  </span>
                </Link>
              ))}
              
              <div
                className="relative"
                onMouseEnter={() => setActiveDropdown('collections')}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <button className="flex items-center gap-1 text-sm font-medium px-3 py-2 rounded-md hover-elevate" data-testid="button-collections">
                  COLLECTIONS <ChevronDown className="w-4 h-4" />
                </button>
                
                {activeDropdown === 'collections' && (
                  <div className="absolute top-full left-0 mt-1 bg-popover border border-popover-border rounded-md shadow-lg min-w-[700px] p-6" data-testid="dropdown-collections">
                    <div className="grid grid-cols-3 gap-6">
                      {capCategories.map((category) => (
                        <div key={category.title}>
                          <h4 className="font-bold text-sm mb-3">{category.title}</h4>
                          <ul className="space-y-2">
                            {category.subcategories.map((sub) => (
                              <li key={sub}>
                                <Link href={`/collection/${sub.toLowerCase().replace(/\s+/g, '-')}`}>
                                  <span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer block py-1">
                                    {sub}
                                  </span>
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {navItems.slice(3).map((item) => (
                <Link key={item.path} href={item.path}>
                  <span className="text-sm font-medium px-3 py-2 rounded-md hover-elevate cursor-pointer" data-testid={`link-${item.label.toLowerCase().replace(/\s+/g, '-')}`}>
                    {item.label}
                  </span>
                </Link>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              data-testid="button-search"
            >
              <Search className="w-5 h-5" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              className="relative"
              data-testid="button-cart"
            >
              <ShoppingCart className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs w-5 h-5 rounded-full flex items-center justify-center" data-testid="text-cart-count">
                3
              </span>
            </Button>

            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {isSearchOpen && (
          <div className="pb-4" data-testid="search-bar">
            <Input
              type="search"
              placeholder="Search for caps..."
              className="w-full"
              data-testid="input-search"
            />
          </div>
        )}
      </div>

      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-border" data-testid="mobile-menu">
          <div className="px-4 py-3 space-y-3">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <span
                  className="block px-3 py-2 rounded-md text-base font-medium hover-elevate cursor-pointer"
                  onClick={() => setIsMobileMenuOpen(false)}
                  data-testid={`link-mobile-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {item.label}
                </span>
              </Link>
            ))}
            <div className="pt-3 border-t border-border">
              <p className="text-sm font-bold px-3 mb-2">Cap Collections</p>
              {capCategories.map((category) => (
                <div key={category.title} className="mb-3">
                  <p className="text-sm font-semibold px-3 py-1">{category.title}</p>
                  {category.subcategories.slice(0, 3).map((sub) => (
                    <Link key={sub} href={`/collection/${sub.toLowerCase().replace(/\s+/g, '-')}`}>
                      <span className="block px-6 py-1 text-sm text-muted-foreground cursor-pointer">
                        {sub}
                      </span>
                    </Link>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
