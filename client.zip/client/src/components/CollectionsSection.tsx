import CollectionCard from "./CollectionCard";
import baseball from "@assets/stock_images/baseball_cap_collect_2f97991c.jpg";
import trucker from "@assets/stock_images/stylish_trucker_cap__b5550fe7.jpg";
import bucket from "@assets/stock_images/bucket_hat_fashion_l_b9d2c6fa.jpg";
import flatVisor from "@assets/stock_images/flat_visor_cap_snapb_0f80e268.jpg";

const collections = [
  { id: "baseball", image: baseball, title: "Baseball Caps", itemCount: 45 },
  { id: "trucker", image: trucker, title: "Trucker Caps", itemCount: 32 },
  { id: "bucket", image: bucket, title: "Bucket Hats", itemCount: 28 },
  { id: "flat-visor", image: flatVisor, title: "Flat Visor Caps", itemCount: 21 },
];

export default function CollectionsSection() {
  return (
    <section className="py-12 md:py-16 bg-muted/30" data-testid="section-collections">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold mb-3" data-testid="text-collections-title">Shop by Collection</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto" data-testid="text-collections-subtitle">
            Discover our diverse range of cap styles - from classic baseball caps to trendy bucket hats
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {collections.map((collection) => (
            <CollectionCard key={collection.id} {...collection} />
          ))}
        </div>
      </div>
    </section>
  );
}
