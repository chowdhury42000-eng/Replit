import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import hero1 from "@assets/stock_images/modern_baseball_cap__54ac3b6e.jpg";
import hero2 from "@assets/stock_images/modern_baseball_cap__157a70d1.jpg";
import hero3 from "@assets/stock_images/modern_baseball_cap__737cf06e.jpg";

const slides = [
  {
    image: hero1,
    title: "Design You Feel on Cap",
    subtitle: "Express Your Style with Premium Headwear",
    cta: "Shop Now",
  },
  {
    image: hero2,
    title: "New Collection 2024",
    subtitle: "Discover Our Latest Cap Designs",
    cta: "Explore Collection",
  },
  {
    image: hero3,
    title: "Limited Edition Caps",
    subtitle: "Exclusive Designs - Limited Stock",
    cta: "Shop Limited Edition",
  },
];

export default function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <div className="relative h-[500px] md:h-[600px] overflow-hidden" data-testid="hero-slider">
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-700 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
          data-testid={`slide-${index}`}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent z-10" />
          <img
            src={slide.image}
            alt={slide.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 z-20 flex items-center justify-center text-center px-4">
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-4" data-testid={`text-hero-title-${index}`}>
                {slide.title}
              </h1>
              <p className="text-lg md:text-xl text-white/90 mb-8" data-testid={`text-hero-subtitle-${index}`}>
                {slide.subtitle}
              </p>
              <Button size="lg" variant="default" data-testid={`button-hero-cta-${index}`}>
                {slide.cta}
              </Button>
            </div>
          </div>
        </div>
      ))}

      <Button
        variant="ghost"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-white/20 hover:bg-white/30 text-white"
        onClick={prevSlide}
        data-testid="button-prev-slide"
      >
        <ChevronLeft className="w-6 h-6" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-white/20 hover:bg-white/30 text-white"
        onClick={nextSlide}
        data-testid="button-next-slide"
      >
        <ChevronRight className="w-6 h-6" />
      </Button>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex gap-2" data-testid="slide-indicators">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentSlide ? "bg-white w-8" : "bg-white/50"
            }`}
            data-testid={`indicator-${index}`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
