import { Heart, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

interface ProductCardProps {
  id: string;
  image: string;
  title: string;
  price: number;
  originalPrice?: number;
  badge?: string;
}

export default function ProductCard({ id, image, title, price, originalPrice, badge }: ProductCardProps) {
  const [isLiked, setIsLiked] = useState(false);

  return (
    <div className="group relative" data-testid={`card-product-${id}`}>
      <div className="relative aspect-square overflow-hidden rounded-md bg-muted mb-3">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          data-testid={`img-product-${id}`}
        />
        
        {badge && (
          <Badge className="absolute top-2 left-2 bg-chart-3 text-white" data-testid={`badge-${badge.toLowerCase()}-${id}`}>
            {badge}
          </Badge>
        )}

        <button
          onClick={() => setIsLiked(!isLiked)}
          className={`absolute top-2 right-2 p-2 rounded-full bg-white/90 hover-elevate active-elevate-2 transition-colors ${
            isLiked ? "text-destructive" : "text-muted-foreground"
          }`}
          data-testid={`button-wishlist-${id}`}
          aria-label="Add to wishlist"
        >
          <Heart className={`w-4 h-4 ${isLiked ? "fill-current" : ""}`} />
        </button>

        <Button
          size="sm"
          className="absolute bottom-2 left-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
          data-testid={`button-quick-add-${id}`}
        >
          <ShoppingCart className="w-4 h-4 mr-2" />
          Quick Add
        </Button>
      </div>

      <h3 className="font-medium text-sm mb-1" data-testid={`text-product-title-${id}`}>{title}</h3>
      <div className="flex items-center gap-2">
        <span className="font-bold text-foreground" data-testid={`text-price-${id}`}>${price}</span>
        {originalPrice && (
          <span className="text-sm text-muted-foreground line-through" data-testid={`text-original-price-${id}`}>
            ${originalPrice}
          </span>
        )}
      </div>
    </div>
  );
}
