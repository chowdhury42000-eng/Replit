import { Facebook, Instagram, Twitter, Mail } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Footer() {
  return (
    <footer className="bg-card border-t border-card-border mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-bold mb-4" data-testid="text-footer-about-title">Friute Cap</h3>
            <p className="text-sm text-muted-foreground mb-4" data-testid="text-footer-about-description">
              Design You Feel on Cap - Express your style with our premium collection of baseball caps, trucker hats, and bucket hats.
            </p>
            <div className="flex gap-3">
              <Button variant="ghost" size="icon" className="hover-elevate" data-testid="button-facebook">
                <Facebook className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover-elevate" data-testid="button-instagram">
                <Instagram className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover-elevate" data-testid="button-twitter">
                <Twitter className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4" data-testid="text-footer-shop-title">Shop</h3>
            <ul className="space-y-2">
              <li><Link href="/baseball-caps" data-testid="link-baseball-caps"><span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">Baseball Caps</span></Link></li>
              <li><Link href="/trucker-caps" data-testid="link-trucker-caps"><span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">Trucker Caps</span></Link></li>
              <li><Link href="/bucket-hats" data-testid="link-bucket-hats"><span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">Bucket Hats</span></Link></li>
              <li><Link href="/limited-edition" data-testid="link-limited-edition"><span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">Limited Edition</span></Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4" data-testid="text-footer-support-title">Customer Service</h3>
            <ul className="space-y-2">
              <li><Link href="/order-status" data-testid="link-footer-order-status"><span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">Order Status</span></Link></li>
              <li><Link href="/shipping" data-testid="link-shipping"><span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">Shipping Info</span></Link></li>
              <li><Link href="/returns" data-testid="link-returns"><span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">Returns</span></Link></li>
              <li><Link href="/contact" data-testid="link-footer-contact"><span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">Contact Us</span></Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4" data-testid="text-footer-newsletter-title">Newsletter</h3>
            <p className="text-sm text-muted-foreground mb-4" data-testid="text-footer-newsletter-description">
              Subscribe to get special offers and updates
            </p>
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                className="flex-1"
                data-testid="input-newsletter-email"
              />
              <Button data-testid="button-newsletter-subscribe">
                <Mail className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground" data-testid="text-copyright">
            © 2024 Friute Cap. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link href="/privacy" data-testid="link-privacy">
              <span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">Privacy Policy</span>
            </Link>
            <Link href="/terms" data-testid="link-terms">
              <span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">Terms of Service</span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
