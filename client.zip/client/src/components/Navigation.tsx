import { Search, ShoppingCart, Menu, X } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const navItems = [
    { label: "Homepage", path: "/" },
    { label: "Design You Feel on Cap", path: "/design" },
    { label: "Design Preview", path: "/preview" },
    { label: "Order Status", path: "/order-status" },
    { label: "About", path: "/about" },
    { label: "Contact", path: "/contact" },
  ];

  return (
    <>
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-8">
              <Link href="/" data-testid="link-home">
                <span className="text-2xl font-bold text-primary cursor-pointer">Friute Cap</span>
              </Link>
              
              <div className="hidden lg:flex items-center gap-6">
                {navItems.map((item) => (
                  <Link key={item.path} href={item.path} data-testid={`link-${item.label.toLowerCase().replace(/\s+/g, '-')}`}>
                    <span className="text-sm font-medium text-foreground hover-elevate cursor-pointer px-3 py-2 rounded-md transition-colors">
                      {item.label}
                    </span>
                  </Link>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                data-testid="button-search"
              >
                <Search className="w-5 h-5" />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                className="relative"
                data-testid="button-cart"
              >
                <ShoppingCart className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs w-5 h-5 rounded-full flex items-center justify-center" data-testid="text-cart-count">
                  3
                </span>
              </Button>

              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                data-testid="button-mobile-menu"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>

          {isSearchOpen && (
            <div className="pb-4" data-testid="search-bar">
              <Input
                type="search"
                placeholder="Search for caps..."
                className="w-full"
                data-testid="input-search"
              />
            </div>
          )}
        </div>

        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-border" data-testid="mobile-menu">
            <div className="px-4 py-3 space-y-1">
              {navItems.map((item) => (
                <Link key={item.path} href={item.path}>
                  <span
                    className="block px-3 py-2 rounded-md text-base font-medium text-foreground hover-elevate cursor-pointer"
                    onClick={() => setIsMobileMenuOpen(false)}
                    data-testid={`link-mobile-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {item.label}
                  </span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>
    </>
  );
}
