import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRef } from "react";

interface Product {
  id: string;
  image: string;
  title: string;
}

interface HorizontalProductScrollProps {
  title: string;
  products: Product[];
}

export default function HorizontalProductScroll({ title, products }: HorizontalProductScrollProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const sectionId = title.toLowerCase().replace(/\s+/g, '-');

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 300;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="py-12" data-testid={`section-${sectionId}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl md:text-3xl font-bold" data-testid={`text-${sectionId}-title`}>{title}</h2>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => scroll('left')}
              data-testid={`button-scroll-left-${sectionId}`}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => scroll('right')}
              data-testid={`button-scroll-right-${sectionId}`}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide scroll-smooth"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {products.map((product) => (
            <div
              key={product.id}
              className="flex-shrink-0 w-[250px] group cursor-pointer"
              data-testid={`product-scroll-${product.id}`}
            >
              <div className="aspect-square overflow-hidden rounded-lg mb-3 hover-elevate">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </div>
              <h3 className="text-sm font-medium text-center" data-testid={`text-product-${product.id}`}>
                {product.title}
              </h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
