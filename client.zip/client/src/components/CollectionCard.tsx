import { ArrowRight } from "lucide-react";

interface CollectionCardProps {
  id: string;
  image: string;
  title: string;
  itemCount?: number;
}

export default function CollectionCard({ id, image, title, itemCount }: CollectionCardProps) {
  return (
    <div
      className="group relative overflow-hidden rounded-lg cursor-pointer hover-elevate"
      data-testid={`card-collection-${id}`}
    >
      <div className="aspect-[4/3] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          data-testid={`img-collection-${id}`}
        />
      </div>
      
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent flex flex-col justify-end p-6">
        <h3 className="text-white text-xl font-bold mb-1" data-testid={`text-collection-title-${id}`}>{title}</h3>
        {itemCount && (
          <p className="text-white/80 text-sm mb-3" data-testid={`text-collection-count-${id}`}>
            {itemCount} Items
          </p>
        )}
        <div className="flex items-center gap-2 text-white opacity-0 group-hover:opacity-100 transition-opacity">
          <span className="text-sm font-medium">Shop Now</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
}
