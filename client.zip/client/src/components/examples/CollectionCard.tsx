import CollectionCard from '../CollectionCard';
import collectionImage from '@assets/stock_images/baseball_cap_collect_2f97991c.jpg';

export default function CollectionCardExample() {
  return (
    <div className="p-6">
      <CollectionCard
        id="baseball"
        image={collectionImage}
        title="Baseball Caps"
        itemCount={45}
      />
    </div>
  );
}
