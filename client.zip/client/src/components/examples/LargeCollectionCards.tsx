import LargeCollectionCards from '../LargeCollectionCards';

export default function LargeCollectionCardsExample() {
  return <LargeCollectionCards />;
}
