import CollectionsSection from '../CollectionsSection';

export default function CollectionsSectionExample() {
  return <CollectionsSection />;
}
