import ProductCard from '../ProductCard';
import product1 from '@assets/stock_images/baseball_cap_collect_2f97991c.jpg';

export default function ProductCardExample() {
  return (
    <div className="p-6">
      <ProductCard
        id="1"
        image={product1}
        title="Classic Baseball Cap"
        price={29.99}
        originalPrice={49.99}
        badge="NEW"
      />
    </div>
  );
}
