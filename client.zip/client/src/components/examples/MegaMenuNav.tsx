import MegaMenuNav from '../MegaMenuNav';

export default function MegaMenuNavExample() {
  return <MegaMenuNav />;
}
