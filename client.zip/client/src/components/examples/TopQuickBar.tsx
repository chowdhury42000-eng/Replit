import TopQuickBar from '../TopQuickBar';

export default function TopQuickBarExample() {
  return <TopQuickBar />;
}
