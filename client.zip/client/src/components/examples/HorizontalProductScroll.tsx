import HorizontalProductScroll from '../HorizontalProductScroll';
import product1 from '@assets/stock_images/baseball_cap_collect_2f97991c.jpg';
import product2 from '@assets/stock_images/baseball_cap_collect_69e4133c.jpg';
import product3 from '@assets/stock_images/baseball_cap_collect_32e1612e.jpg';

const products = [
  { id: "1", image: product1, title: "Classic Baseball Cap" },
  { id: "2", image: product2, title: "Premium Suede Cap" },
  { id: "3", image: product3, title: "Urban Trucker Hat" },
];

export default function HorizontalProductScrollExample() {
  return (
    <HorizontalProductScroll
      title="NEW CAP SERIES"
      products={products}
    />
  );
}
