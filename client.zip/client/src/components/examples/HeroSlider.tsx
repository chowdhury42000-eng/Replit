import HeroSlider from '../HeroSlider';

export default function HeroSliderExample() {
  return <HeroSlider />;
}
