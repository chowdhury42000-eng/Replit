import PromoBanners from '../PromoBanners';

export default function PromoBannersExample() {
  return <PromoBanners />;
}
