import AnnouncementBar from '../AnnouncementBar';

export default function AnnouncementBarExample() {
  return <AnnouncementBar />;
}
