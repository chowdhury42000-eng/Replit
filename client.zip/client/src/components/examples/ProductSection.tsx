import ProductSection from '../ProductSection';
import product1 from '@assets/stock_images/baseball_cap_collect_2f97991c.jpg';
import product2 from '@assets/stock_images/baseball_cap_collect_69e4133c.jpg';
import product3 from '@assets/stock_images/baseball_cap_collect_32e1612e.jpg';

const products = [
  { id: "1", image: product1, title: "Classic Baseball Cap", price: 29.99, badge: "NEW" },
  { id: "2", image: product2, title: "Premium Suede Cap", price: 39.99 },
  { id: "3", image: product3, title: "Urban Trucker Hat", price: 34.99, badge: "TRENDING" },
];

export default function ProductSectionExample() {
  return (
    <ProductSection
      title="New Arrivals"
      subtitle="Check out our latest cap collections"
      products={products}
      viewAllLink="/new-arrivals"
    />
  );
}
