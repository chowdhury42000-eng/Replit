import FlashSaleSection from '../FlashSaleSection';

export default function FlashSaleSectionExample() {
  return <FlashSaleSection />;
}
