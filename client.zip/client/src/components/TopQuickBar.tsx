import { Sparkles, Zap, TrendingUp, Package } from "lucide-react";
import { Link } from "wouter";

export default function TopQuickBar() {
  const quickLinks = [
    { icon: Sparkles, label: "New Arrival!", path: "/new-arrival", testId: "new-arrival" },
    { icon: Zap, label: "Flash Sale", path: "/flash-sale", testId: "flash-sale" },
    { icon: TrendingUp, label: "TOP SELLING", path: "/top-selling", testId: "top-selling" },
    { icon: Package, label: "Available Caps", path: "/available", testId: "available-caps" },
  ];

  return (
    <div className="bg-muted/50 border-b border-border">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-center md:justify-start gap-6 py-3 overflow-x-auto">
          {quickLinks.map((link) => (
            <Link key={link.path} href={link.path}>
              <div
                className="flex items-center gap-2 px-4 py-2 rounded-md hover-elevate cursor-pointer whitespace-nowrap"
                data-testid={`link-quick-${link.testId}`}
              >
                <link.icon className="w-5 h-5 text-primary" />
                <span className="text-sm font-semibold">{link.label}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
