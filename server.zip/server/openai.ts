import OpenAI from "openai";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY environment variable is required for AI cap designer");
}

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generateCapDesign(prompt: string, capStyle: string): Promise<{ url: string }> {
  const enhancedPrompt = `Create a high-quality product photograph of a ${capStyle} cap with the following design: ${prompt}. 
  
The image should be:
- Professional product photography style
- Clean white or neutral background
- Well-lit with soft shadows
- Cap should be the main focus, shown from a flattering angle
- Design elements should be clearly visible and vibrant
- Photorealistic quality suitable for e-commerce`;

  try {
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: enhancedPrompt,
      n: 1,
      size: "1024x1024",
      quality: "standard",
    });

    if (!response.data[0]?.url) {
      throw new Error("No image URL returned from OpenAI");
    }

    return { url: response.data[0].url };
  } catch (error: any) {
    console.error("OpenAI image generation failed:", {
      error: error.message,
      capStyle,
      promptLength: prompt.length,
    });
    throw new Error(`Failed to generate cap design: ${error.message || 'Unknown error'}`);
  }
}
