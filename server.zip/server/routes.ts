import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateCapDesign } from "./openai";
import { checkRateLimit } from "./rateLimit";

export async function registerRoutes(app: Express): Promise<Server> {
  // Design Management APIs
  app.get("/api/designs", async (_req, res) => {
    try {
      const allDesigns = await storage.getAllDesigns();
      res.json(allDesigns);
    } catch (error: any) {
      console.error("Error fetching designs:", error);
      res.status(500).json({ message: "Failed to fetch designs" });
    }
  });

  app.get("/api/designs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid design ID" });
      }

      const design = await storage.getDesign(id);
      if (!design) {
        return res.status(404).json({ message: "Design not found" });
      }

      res.json(design);
    } catch (error: any) {
      console.error("Error fetching design:", error);
      res.status(500).json({ message: "Failed to fetch design" });
    }
  });

  app.post("/api/designs", async (req, res) => {
    try {
      const { imageUrl, prompt, capStyle } = req.body;

      if (!imageUrl || !prompt || !capStyle) {
        return res.status(400).json({ 
          message: "Missing required fields: imageUrl, prompt, and capStyle" 
        });
      }

      const design = await storage.createDesign({ imageUrl, prompt, capStyle });
      res.status(201).json(design);
    } catch (error: any) {
      console.error("Error creating design:", error);
      res.status(500).json({ message: "Failed to save design" });
    }
  });

  app.delete("/api/designs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid design ID" });
      }

      await storage.deleteDesign(id);
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting design:", error);
      res.status(500).json({ message: "Failed to delete design" });
    }
  });

  // AI Cap Design Generation API
  app.post("/api/ai/generate-cap-design", async (req, res) => {
    try {
      const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
      const rateLimitResult = checkRateLimit(clientIp);

      if (!rateLimitResult.allowed) {
        res.setHeader('Retry-After', rateLimitResult.retryAfter?.toString() || '60');
        return res.status(429).json({
          message: `Rate limit exceeded. Please try again in ${rateLimitResult.retryAfter} seconds.`,
        });
      }

      const { prompt, capStyle } = req.body;

      if (!prompt || !capStyle) {
        return res.status(400).json({ 
          message: "Missing required fields: prompt and capStyle" 
        });
      }

      if (typeof prompt !== 'string' || prompt.trim().length === 0) {
        return res.status(400).json({ 
          message: "Prompt must be a non-empty string" 
        });
      }

      if (prompt.length > 1000) {
        return res.status(400).json({ 
          message: "Prompt is too long. Maximum 1000 characters allowed." 
        });
      }

      const validCapStyles = ['baseball', 'trucker', 'snapback', 'bucket', 'dad-hat'];
      if (typeof capStyle !== 'string' || !validCapStyles.includes(capStyle)) {
        return res.status(400).json({ 
          message: `Invalid cap style. Must be one of: ${validCapStyles.join(', ')}` 
        });
      }

      const result = await generateCapDesign(prompt, capStyle);

      res.json({
        imageUrl: result.url,
        prompt: prompt,
      });
    } catch (error: any) {
      console.error("AI generation error:", error);
      res.status(500).json({ 
        message: error.message || "Failed to generate cap design" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
