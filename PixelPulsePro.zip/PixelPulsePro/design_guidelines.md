# AI Automation BD Website Design Guidelines

## Design Approach
**System-Based Approach**: Using modern Material Design principles adapted for a professional B2B tech company, emphasizing trust, efficiency, and cultural relevance for the Bangladeshi market.

## Core Design Elements

### Color Palette
**Primary Colors:**
- Deep Blue: 220 85% 25% (professional, trustworthy)
- Accent Blue: 210 100% 50% (CTAs, highlights)

**Supporting Colors:**
- Success Green: 140 70% 45% (for positive actions)
- Warning Orange: 25 90% 55% (notifications)
- Neutral Grays: 220 10% 95%, 220 15% 85%, 220 20% 60%

**Dark Mode:**
- Background: 220 25% 8%
- Surface: 220 20% 12%
- Text Primary: 0 0% 95%

### Typography
- **Primary Font**: Noto Sans Bengali (Google Fonts) for Bangla text
- **Secondary Font**: Inter (Google Fonts) for English text
- **Hierarchy**: H1 (2.5rem), H2 (2rem), H3 (1.5rem), Body (1rem)
- **Weights**: Regular (400), Medium (500), SemiBold (600)

### Layout System
**Spacing Units**: Tailwind 4, 8, 12, 16, 24 (p-4, m-8, gap-12, etc.)
- Container max-width: 1200px
- Grid system: 12-column responsive grid
- Section padding: py-16 on desktop, py-12 on mobile

### Component Library

**Navigation:**
- Clean horizontal navbar with company logo
- Mobile hamburger menu with slide-out drawer
- Sticky header with subtle shadow on scroll

**Forms:**
- Rounded input fields with subtle borders
- Focus states with primary blue outline
- Validation with inline error messages
- CTA buttons with solid fills, secondary buttons with outline variants

**Cards:**
- Subtle shadows with rounded corners (rounded-lg)
- Hover states with gentle elevation increase
- Service cards with icon, title, description layout

**Content Sections:**
- Hero section with compelling headline and CTA
- Services grid with 3-column layout (responsive to 1-column mobile)
- Case studies carousel with previous/next navigation
- Team member cards with photos and bio previews

### Interactions
- Smooth scroll behavior for anchor links
- Subtle hover animations (transform scale-105)
- Loading states for form submissions
- Smooth page transitions

## Page-Specific Guidelines

**Homepage:**
- Large hero section with company value proposition
- Services overview with icon-based cards
- Client testimonials section
- Recent case studies preview
- Contact CTA section

**Services Page:**
- Detailed service cards with pricing indicators
- Process explanation with numbered steps
- FAQ accordion section

**Blog/Case Studies:**
- Card-based layout with featured images
- Category filtering
- Search functionality
- Reading time indicators

**Admin CMS:**
- Clean dashboard with sidebar navigation
- Form-heavy interface with clear visual hierarchy
- Data tables with sorting and filtering
- WYSIWYG editor for content creation

## Images
- **Hero Image**: Large, professional team photo or AI/automation visualization
- **Service Icons**: Custom illustrated icons for each service type
- **Case Study Images**: Screenshots or results visualizations
- **Team Photos**: Professional headshots with consistent styling
- **Blog Images**: Relevant stock photos or custom graphics
- All images optimized for web with lazy loading implementation

## Mobile Considerations
- Mobile-first responsive design
- Touch-friendly button sizes (minimum 44px)
- Readable text sizes on small screens
- Simplified navigation for mobile users
- WhatsApp integration prominently displayed on mobile