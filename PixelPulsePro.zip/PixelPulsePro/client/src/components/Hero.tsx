import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, CheckCircle, ArrowRight, Play } from "lucide-react";
import heroImage from '@assets/generated_images/AI_team_professional_photo_b649a613.png';

export default function Hero() {
  const features = [
    "Reduce costs by 80%",
    "Complete work 5x faster",
    "24/7 automated service"
  ];

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-background via-background to-muted/20 py-16 md:py-24">
      <div className="container grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
        {/* Content */}
        <div className="flex flex-col space-y-8">
          <div className="space-y-6">
            <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-5xl lg:text-6xl">
              Solve Your Business Problems with AI, Reduce Costs, Increase Revenue.
            </h1>
            <p className="text-xl text-muted-foreground md:text-2xl">
              We are Bangladesh's first AI Automation company — creating customized solutions for businesses.
            </p>
          </div>

          {/* Features */}
          <div className="space-y-3">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center space-x-3">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span className="text-foreground font-medium">{feature}</span>
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              size="lg" 
              className="text-lg px-8 py-6"
              onClick={() => console.log('Book Free Strategy Call clicked')}
              data-testid="button-hero-cta"
            >
              <Phone className="h-5 w-5 mr-2" />
              Book Free Strategy Call
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="text-lg px-8 py-6"
              onClick={() => console.log('Watch Demo clicked')}
              data-testid="button-hero-demo"
            >
              <Play className="h-5 w-5 mr-2" />
              Watch Demo
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="pt-6 border-t border-border">
            <p className="text-sm text-muted-foreground mb-4">
              Already 100+ companies are using our services
            </p>
            <div className="flex items-center space-x-8 opacity-60">
              <span className="text-sm font-medium">TechCrunch</span>
              <span className="text-sm font-medium">Forbes</span>
              <span className="text-sm font-medium">The Daily Star</span>
            </div>
          </div>
        </div>

        {/* Hero Image */}
        <div className="relative">
          <Card className="overflow-hidden">
            <CardContent className="p-0">
              <img
                src={heroImage}
                alt="AI Automation BD Team"
                className="aspect-video w-full object-cover"
                loading="eager"
              />
            </CardContent>
          </Card>
          
          {/* Video Play Button Overlay */}
          <Button
            size="icon"
            className="absolute inset-0 m-auto h-16 w-16 rounded-full bg-primary/90 hover:bg-primary"
            onClick={() => console.log('Hero video play clicked')}
            data-testid="button-hero-video"
          >
            <Play className="h-6 w-6 text-primary-foreground" />
          </Button>
        </div>
      </div>
    </section>
  );
}