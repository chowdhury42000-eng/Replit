import ContactForm from '../ContactForm';

export default function ContactFormExample() {
  return <ContactForm />;
}