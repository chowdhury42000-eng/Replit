import WhatsAppButton from '../WhatsAppButton';

export default function WhatsAppButtonExample() {
  return (
    <div className="h-96 relative bg-muted/20">
      <p className="p-8 text-muted-foreground">
        WhatsApp button will appear in the bottom right corner after a few seconds.
      </p>
      <WhatsAppButton />
    </div>
  );
}