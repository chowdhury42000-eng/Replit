import CaseStudies from '../CaseStudies';

export default function CaseStudiesExample() {
  return <CaseStudies />;
}