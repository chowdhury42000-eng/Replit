import CookieConsent from '../CookieConsent';

export default function CookieConsentExample() {
  return (
    <div className="h-96 relative bg-muted/20">
      <p className="p-8 text-muted-foreground">
        Cookie consent banner will appear at the bottom after a few seconds.
      </p>
      <CookieConsent />
    </div>
  );
}