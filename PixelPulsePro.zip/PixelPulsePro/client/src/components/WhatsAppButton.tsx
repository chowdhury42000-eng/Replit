import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { MessageCircle, X } from "lucide-react";

export default function WhatsAppButton() {
  const [isVisible, setIsVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  // Show button after page load
  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 2000);
    return () => clearTimeout(timer);
  }, []);

  // Auto expand after showing
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => setIsExpanded(true), 1000);
      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  // Auto collapse after expansion
  useEffect(() => {
    if (isExpanded) {
      const timer = setTimeout(() => setIsExpanded(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [isExpanded]);

  const handleWhatsAppClick = () => {
    console.log('WhatsApp floating button clicked');
    const message = encodeURIComponent("Hello! I want to know about AI Automation services.");
    const phone = "8801234567890";
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  const handleClose = () => {
    setIsExpanded(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center space-x-3">
      {/* Expanded Message */}
      {isExpanded && (
        <div className="bg-white dark:bg-card border border-border rounded-lg shadow-lg p-4 max-w-xs animate-in slide-in-from-right">
          <div className="flex items-start justify-between space-x-2">
            <div className="flex-1">
              <p className="text-sm font-medium mb-1">AI Automation BD</p>
              <p className="text-xs text-muted-foreground">
                Want to talk about AI solutions for your business? Contact us now!
              </p>
            </div>
            <Button
              size="icon"
              variant="ghost"
              className="h-6 w-6 shrink-0"
              onClick={handleClose}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
          <Button
            size="sm"
            className="w-full mt-3 bg-green-600 hover:bg-green-700 text-white"
            onClick={handleWhatsAppClick}
          >
            Chat on WhatsApp
          </Button>
        </div>
      )}

      {/* WhatsApp Button */}
      <Button
        size="icon"
        className="h-14 w-14 rounded-full bg-green-600 hover:bg-green-700 text-white shadow-lg hover:shadow-xl transition-all"
        onClick={isExpanded ? handleWhatsAppClick : () => setIsExpanded(true)}
        data-testid="button-whatsapp-floating"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>
    </div>
  );
}