import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Clock, DollarSign, Users, ArrowRight } from "lucide-react";
import dashboardImage from '@assets/generated_images/AI_automation_dashboard_interface_4714fc3f.png';
import ecommerceImage from '@assets/generated_images/E-commerce_automation_workflow_dfdada0f.png';

const caseStudies = [
  {
    id: 1,
    title: "E-commerce Store Automation",
    client: "ShopBD Limited",
    challenge: "Manual processing of 500+ orders daily",
    solution: "Complete order processing and customer support automation",
    results: {
      timeSaved: "80 hours/week",
      roi: "350%",
      efficiency: "95%"
    },
    technologies: ["WhatsApp API", "Inventory Management", "Payment Gateway"],
    image: ecommerceImage,
    quote: "AI Automation BD has revolutionized our business. Now we can handle 3 times more orders.",
    author: "Mohammad Rahim, CEO"
  },
  {
    id: 2,
    title: "Healthcare CRM System",
    client: "Medical Center",
    challenge: "Patient appointment and record management",
    solution: "AI-powered patient management and automatic reminders",
    results: {
      timeSaved: "60 hours/week",
      roi: "280%",
      efficiency: "92%"
    },
    technologies: ["Custom AI", "SMS Integration", "Database Management"],
    image: dashboardImage,
    quote: "Patient service is now faster and more accurate. Staff can now focus on more important tasks.",
    author: "Dr. Fatema Khan, Director"
  }
];

export default function CaseStudies() {
  return (
    <section className="py-16 md:py-24">
      <div className="container">
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="text-sm px-4 py-2">
            <TrendingUp className="h-4 w-4 mr-2" />
            Success Stories
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold">
            Our Clients' Success
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            See how our AI solutions have brought business success
          </p>
        </div>

        {/* Case Studies */}
        <div className="space-y-12">
          {caseStudies.map((study, index) => (
            <Card key={study.id} className={`overflow-hidden ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
              <div className="lg:flex">
                {/* Image */}
                <div className="lg:w-1/2">
                  <img
                    src={study.image}
                    alt={study.title}
                    className="aspect-video w-full object-cover lg:aspect-square"
                  />
                </div>

                {/* Content */}
                <div className="lg:w-1/2 p-8 lg:p-12 space-y-6">
                  <div className="space-y-4">
                    <Badge variant="outline">{study.client}</Badge>
                    <CardTitle className="text-2xl lg:text-3xl">{study.title}</CardTitle>
                  </div>

                  {/* Challenge & Solution */}
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-destructive mb-2">Challenge:</h4>
                      <p className="text-muted-foreground">{study.challenge}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-primary mb-2">Solution:</h4>
                      <p className="text-muted-foreground">{study.solution}</p>
                    </div>
                  </div>

                  {/* Results */}
                  <div className="grid grid-cols-3 gap-4 py-6 border-y border-border">
                    <div className="text-center">
                      <Clock className="h-6 w-6 text-primary mx-auto mb-2" />
                      <div className="font-bold text-lg text-primary">{study.results.timeSaved}</div>
                      <div className="text-sm text-muted-foreground">Time Saved</div>
                    </div>
                    <div className="text-center">
                      <DollarSign className="h-6 w-6 text-primary mx-auto mb-2" />
                      <div className="font-bold text-lg text-primary">{study.results.roi}</div>
                      <div className="text-sm text-muted-foreground">ROI Increase</div>
                    </div>
                    <div className="text-center">
                      <TrendingUp className="h-6 w-6 text-primary mx-auto mb-2" />
                      <div className="font-bold text-lg text-primary">{study.results.efficiency}</div>
                      <div className="text-sm text-muted-foreground">Efficiency</div>
                    </div>
                  </div>

                  {/* Technologies */}
                  <div>
                    <h4 className="font-semibold mb-3">Technologies Used:</h4>
                    <div className="flex flex-wrap gap-2">
                      {study.technologies.map((tech) => (
                        <Badge key={tech} variant="secondary">{tech}</Badge>
                      ))}
                    </div>
                  </div>

                  {/* Quote */}
                  <blockquote className="border-l-4 border-primary pl-4 italic">
                    <p className="text-muted-foreground mb-2">"{study.quote}"</p>
                    <cite className="text-sm font-medium">— {study.author}</cite>
                  </blockquote>

                  {/* CTA */}
                  <Button 
                    onClick={() => console.log(`Case study ${study.id} details clicked`)}
                    data-testid={`button-case-study-${study.id}`}
                  >
                    View Details
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <Button 
            size="lg" 
            variant="outline"
            className="px-8"
            onClick={() => console.log('All Case Studies clicked')}
            data-testid="button-all-case-studies"
          >
            View All Case Studies
            <ArrowRight className="h-5 w-5 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
}