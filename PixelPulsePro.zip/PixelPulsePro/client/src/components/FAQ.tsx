import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { HelpCircle } from "lucide-react";

const faqs = [
  {
    question: "What is AI Automation and how will it help my business?",
    answer: "AI Automation is the use of artificial intelligence to automate business processes. It will save your time, reduce costs, and increase efficiency. For example, customer service, order processing, and marketing campaigns can be automated."
  },
  {
    question: "Is AI Automation affordable for my small business?",
    answer: "Yes, we offer affordable packages for small businesses. After the initial investment, you will save significantly in the long run. Our smallest package starts from $120 per month."
  },
  {
    question: "How long does it take to set up an AI system?",
    answer: "Generally, we can set up a basic AI system within 2-4 weeks. For complex customizations, it may take 6-8 weeks. We keep you updated at every stage."
  },
  {
    question: "Will the AI system work with my existing software?",
    answer: "Yes, we integrate with various popular software and platforms. This includes CRM systems, e-commerce platforms, accounting software and many more."
  },
  {
    question: "What about support and maintenance?",
    answer: "We provide 24/7 technical support. Regular updates, bug fixes and performance optimization are included with each plan. Our team is always ready to serve you."
  },
  {
    question: "How secure is data?",
    answer: "We use enterprise grade security. All your data is encrypted and we follow GDPR and SOC 2 compliance. Your data is only used with your permission."
  },
  {
    question: "When will I get ROI (Return on Investment)?",
    answer: "Generally, you will see the return on investment within 3-6 months. Our clients have received an average of 300-500% ROI in the first year itself. The actual numbers depend on your business type and usage."
  },
  {
    question: "Will employees need to be laid off?",
    answer: "No, the purpose of AI Automation is not to replace employees, but to make them more efficient. Your team will be able to focus on more important and creative work. We also help with employee training."
  }
];

export default function FAQ() {
  return (
    <section className="py-16 md:py-24">
      <div className="container">
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="text-sm px-4 py-2">
            <HelpCircle className="h-4 w-4 mr-2" />
            Frequently Asked Questions
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold">
            Answers to All Your Questions
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Find answers to common questions about AI Automation here
          </p>
        </div>

        {/* FAQ Accordion */}
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border rounded-lg px-6">
                <AccordionTrigger 
                  className="text-left py-6 hover:no-underline"
                  data-testid={`faq-trigger-${index}`}
                >
                  <span className="text-base font-medium pr-4">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="pb-6 text-muted-foreground leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}