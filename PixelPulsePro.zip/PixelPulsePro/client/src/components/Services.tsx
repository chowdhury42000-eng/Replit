import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, ShoppingCart, Stethoscope, HeadphonesIcon, ArrowRight, Zap } from "lucide-react";

const services = [
  {
    icon: Bot,
    title: "Lead Generation AI Agent",
    description: "Automated lead generation with LinkedIn and Email Outreach",
    features: ["LinkedIn Automation", "Email Campaigns", "Lead Qualification"],
    popular: true
  },
  {
    icon: ShoppingCart,
    title: "E-commerce Automation",
    description: "Complete automation of orders, invoices, WhatsApp and marketing",
    features: ["Order Processing", "Inventory Management", "Customer Messaging"],
    popular: false
  },
  {
    icon: Stethoscope,
    title: "Custom AI Agents",
    description: "Specialized AI solutions for CRM, Healthcare, and Finance",
    features: ["Custom Development", "Industry Specific", "API Integration"],
    popular: false
  },
  {
    icon: HeadphonesIcon,
    title: "Customer Service AI",
    description: "24/7 customer support service with Voice + Chat",
    features: ["24/7 Support", "Multi-language", "Voice & Text"],
    popular: false
  }
];

export default function Services() {
  return (
    <section className="py-16 md:py-24 bg-muted/50">
      <div className="container">
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="text-sm px-4 py-2">
            <Zap className="h-4 w-4 mr-2" />
            Our Services
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold">
            Advance Your Business with AI
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            AI solutions specially designed for every business
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4">
          {services.map((service, index) => (
            <Card key={index} className="relative group hover-elevate border-border">
              {service.popular && (
                <Badge 
                  className="absolute -top-2 left-4 bg-primary text-primary-foreground z-10"
                >
                  Popular
                </Badge>
              )}
              
              <CardHeader className="space-y-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <service.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-xl">{service.title}</CardTitle>
                <CardDescription className="text-base">
                  {service.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Features */}
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary mr-3" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <Button 
                  variant="outline" 
                  className="w-full group"
                  onClick={() => console.log(`See Example clicked for ${service.title}`)}
                  data-testid={`button-service-${index}`}
                >
                  See Example
                  <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <Button 
            size="lg" 
            className="px-8"
            onClick={() => console.log('All Services clicked')}
            data-testid="button-all-services"
          >
            View All Services
            <ArrowRight className="h-5 w-5 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
}