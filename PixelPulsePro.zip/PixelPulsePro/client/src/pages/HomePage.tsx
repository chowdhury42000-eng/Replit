import Hero from "@/components/Hero";
import Services from "@/components/Services";
import CaseStudies from "@/components/CaseStudies";
import FAQ from "@/components/FAQ";
import ContactForm from "@/components/ContactForm";

export default function HomePage() {
  return (
    <main>
      <Hero />
      <Services />
      <CaseStudies />
      <FAQ />
      <ContactForm />
    </main>
  );
}