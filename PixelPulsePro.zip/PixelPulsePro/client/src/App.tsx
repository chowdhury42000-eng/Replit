import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import CookieConsent from "@/components/CookieConsent";
import ThemeToggle from "@/components/ThemeToggle";
import HomePage from "@/pages/HomePage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      {/* Future pages */}
      {/* <Route path="/services" component={ServicesPage} /> */}
      {/* <Route path="/case-studies" component={CaseStudiesPage} /> */}
      {/* <Route path="/blog" component={BlogPage} /> */}
      {/* <Route path="/about" component={AboutPage} /> */}
      {/* <Route path="/contact" component={ContactPage} /> */}
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="ai-automation-bd-theme">
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <div className="min-h-screen flex flex-col">
            {/* Header with Theme Toggle */}
            <div className="relative">
              <Header />
              <div className="absolute top-4 right-4 z-40">
                <ThemeToggle />
              </div>
            </div>
            
            {/* Main Content */}
            <div className="flex-1">
              <Router />
            </div>
            
            {/* Footer */}
            <Footer />
            
            {/* Floating Elements */}
            <WhatsAppButton />
            <CookieConsent />
          </div>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
